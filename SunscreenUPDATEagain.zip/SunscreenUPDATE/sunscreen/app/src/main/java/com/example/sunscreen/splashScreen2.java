package com.example.sunscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class splashScreen2 extends AppCompatActivity {

    Timer timer = new Timer();

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen2);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent1 = getIntent();
                String flag = intent1.getStringExtra("flag");
                Intent intent = new Intent(splashScreen2.this, results2.class);
                intent.putExtra("flag", flag);
                startActivity(intent);
                finish();
            }
        }, 3000);
    }
}


