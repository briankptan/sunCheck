package com.example.sunscreen;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class facts extends AppCompatActivity {

    BottomNavigationView navView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facts);

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        navView = findViewById(R.id.nav_facts);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_check: {
                        Intent intent = new Intent(facts.this, cameraActivity.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_home: {
                        Intent intent = new Intent(facts.this, MainActivity.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });


    }
}
