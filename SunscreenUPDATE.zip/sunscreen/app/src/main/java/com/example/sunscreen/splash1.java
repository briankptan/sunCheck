package com.example.sunscreen;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class splash1 extends AppCompatActivity {

    Timer timer = new Timer();
    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash1);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(splash1.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        },1500);

    }
}
