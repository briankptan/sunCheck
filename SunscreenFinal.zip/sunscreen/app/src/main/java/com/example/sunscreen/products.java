package com.example.sunscreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class products extends AppCompatActivity {

    TextView prod;
    BottomNavigationView bottomNavigationView;

    @SuppressLint({"WrongConstant", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.nav_productView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_check: {
                        Intent intent = new Intent(products.this, cameraActivity.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_facts: {
                        Intent intent = new Intent(products.this, facts.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_impact:{
                        Intent intent = new Intent(products.this, impact.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_home:{
                        Intent intent = new Intent(products.this, MainActivity.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });

        prod = findViewById(R.id.recommend);





    }
}
