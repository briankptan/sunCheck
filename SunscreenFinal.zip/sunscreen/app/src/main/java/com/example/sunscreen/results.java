package com.example.sunscreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class results extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        bottomNavigationView = findViewById(R.id.nav_results);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.navigation_home:{
                        Intent intent = new Intent(results.this, MainActivity.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_check:{
                        Intent intent = new Intent(results.this, cameraActivity.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_facts: {
                        Intent intent = new Intent(results.this, facts.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_impact:{
                        Intent intent = new Intent(results.this, impact.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });
    }
}
