package com.example.sunscreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;

public class impact extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    TextView amountResult, psa, instruc;
    EditText num;
    Button calculate, clear;

    DecimalFormat df = new DecimalFormat("0.00");

    @SuppressLint({"WrongConstant", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_impact);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.nav_impactView);
        calculate = findViewById(R.id.calcBtn);
        clear = findViewById(R.id.clearBtn);
        amountResult = findViewById(R.id.amount);
        psa = findViewById(R.id.psa);
        instruc = findViewById(R.id.instruc);

        instruc.setText("The amount of Oxybenzone endangering marine life heavily depends on the number of people wearing" +
                " non-ocean friendly sunscreen in the water. Enter a number to calculate that amount.");

        psa.setText("A single drop of Oxybenzone is enough to cause toxicity in an Olympic-sized swimming pool.\n" +
                "- National Oceanic and Atmospheric Administration, USA");


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_check: {
                        Intent intent = new Intent(impact.this, cameraActivity.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_facts: {
                        Intent intent = new Intent(impact.this, facts.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_home: {
                        Intent intent = new Intent(impact.this, MainActivity.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });

        num = findViewById(R.id.numEdit);
        num.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_DONE){
                    String quant = num.getText().toString();
                    try{
                        float equation = (float) ((Float.valueOf(quant) * 18 * 0.06) / 29.573529);
                        if (equation > 0){
                            amountResult.setText("In 1 hour the estimated amount of Oxybenzone released into the ocean: ");
                            amountResult.append("\n\n");
                            amountResult.append(equation + " FL OZ");

                            if (equation < 128){
                                float cups = equation / 8;
                                amountResult.append("\n\n");
                                amountResult.append("That's the equivalent of " + df.format(cups) + " cups");
                            }
                            else{
                                float gallons = equation / 128;
                                amountResult.append("\n\n");
                                amountResult.append("That's the equivalent of " + df.format(gallons) + " gallons");
                            }
                        }
                        else{
                            amountResult.setText("Please enter a number");
                        }
                        }catch (Exception e){
                            amountResult.setText(" ");
                            num.setText(" ");
                        }
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    assert imm != null;
                    imm.hideSoftInputFromWindow(num.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);
                        handled = true;
                }
                return handled;
            }
        });

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String quant = num.getText().toString();
                try{
                    float equation = (float) ((Float.valueOf(quant) * 18 * 0.06) / 29.573529);
                    if (equation > 0){
                        amountResult.setText("In 1 hour the estimated amount of Oxybenzone released into the ocean: ");
                        amountResult.append("\n\n");
                        amountResult.append(equation + " FL OZ");

                        if (equation < 128){
                            float cups = equation / 8;
                            amountResult.append("\n\n");
                            amountResult.append("That's the equivalent of " + df.format(cups) + " cups");
                        }
                        else{
                            float gallons = equation / 128;
                            amountResult.append("\n\n");
                            amountResult.append("That's the equivalent of " + df.format(gallons) + " gallons");
                        }
                    }
                    else{
                        amountResult.setText("Please enter a number");
                    }
                }catch (Exception e){
                    amountResult.setText(" ");
                    num.setText(" ");
                }
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                assert imm != null;
                imm.hideSoftInputFromWindow(calculate.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                amountResult.setText(" ");
                num.setText(" ");
            }
        });
    }
}

