#CALORIES
def cal():
    cal_lookup = 'Calories'
    cal = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if cal_lookup in line:
                index = num + 1
                cal.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        calNum = j
        cal.append(calNum.rstrip('\n'))

        scalories = cal[1]

        try:
            calories = float(scalories)
            print('CALORIES = ', calories)
        except ValueError:
            calories = -999
            print("Please enter Calories manually!")
            
        if calories == -999:
            user_input = float(input("Please enter Calories: "))
            calories = user_input

    return calories
            
#FAT
def fat():
    fat_lookup = 'Fat'
    fat = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if fat_lookup in line:
                index = num + 1
                fat.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        fatNum = j
        fat.append(fatNum.rstrip('\n'))

        t = fat[1]
        temp = list(t)
        temp.pop(1)
        sfats = temp[0]

        try:
            fats = float(sfats)
            print('TOTAL FAT = ', fats)
        except ValueError:
            fats = -999
            print("Please enter Total Fat manually!")
            
        if fats == -999:
            user_input = float(input("Please enter Total Fats: "))
            fats = user_input

    return fats


#CHOLESTEROL
def chol():
    chol_lookup = 'Cholesterol'
    chol = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if chol_lookup in line:
                index = num + 1
                chol.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        cholNum = j
        chol.append(cholNum.rstrip('\n'))

        t = chol[1]
        temp = list(t)
        temp.pop(1)
        temp.pop(1)
        schol = temp[0]

        try:
            cholesterol = float(schol)
            print('CHOLESTEROL = ', cholesterol)
        except ValueError:
            cholesterol = -999
            print("Please enter Cholesterol manually!")

        if cholesterol == -999:
            user_input = float(input("Please enter Cholesterol: "))
            cholesterol = user_input

    return cholesterol

#SODIUM
def sod():
    sod_lookup = 'Sodium'
    sod = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if sod_lookup in line:
                index = num + 1
                sod.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        sodNum = j
        sod.append(sodNum.rstrip('\n'))

        t = sod[1]
        temp = list(t)
        temp.pop(1)
        temp.pop(1)
        ssod = temp[0]
                
        try:
            sodium = float(ssod)
            print('SODIUM = ', sodium)
        except ValueError:
            sodium = -999
            print("Please enter Sodium manually!")

        if sodium == -999:
            user_input = float(input("Please enter Sodium: "))
            sodium = user_input

    return sodium
            

#CARBOHYDRATE
def carb():
    carb_lookup = 'Carbohydrate'
    carb = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if carb_lookup in line:
                index = num + 1
                carb.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        carbNum = j
        carb.append(carbNum.rstrip('\n'))
        
        t = carb[1]
        temp = list(t)
        temp.pop(2)
        scarb = temp[0] + temp[1]
                
        try:
            carbohydrate = float(scarb)
            print('CARBOHYDRATE = ', carbohydrate)
        except ValueError:
            carbohydrate = -999
            print("Please enter Carbohydrate manually!")

        if carbohydrate == -999:
            user_input = float(input("Please enter Carbohydrate: "))
            carbohydrate = user_input

    return carbohydrate

#SUGARS
def sug():
    sug_lookup = 'Sugars'
    sug = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if sug_lookup in line:
                index = num + 1
                sug.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        sugNum = j
        sug.append(sugNum.rstrip('\n'))
                
        t = sug[1]
        temp = list(t)
        temp.pop(1)
        ssug = temp[0]
                
        try:
            sugars = float(ssug)
            print('SUGARS = ', sugars)
        except ValueError:
            sug = -999
            print("Please enter Sugars manually!")

        if sugars == -999:
            user_input = float(input("Please enter Sugars: "))
            sugars = user_input

    return sugars
            

#PROTEIN
def prot():
    prot_lookup = 'Protein'
    prot = []
    with open("/home/emily/Desktop/NutriText.txt") as myFile:
        for num, line in enumerate(myFile, 0):
            if prot_lookup in line:
                index = num + 1
                prot.append(line.rstrip('\n'))
                for i, j in enumerate(myFile, 0):
                    if i == 0:
                        protNum = j
        prot.append(protNum.rstrip('\n'))
                
        t = prot[1]
        temp = list(t)
        temp.pop(1)
        sprot = temp[0]
                
        try:
            protein = float(sprot)
            print('PROTEIN = ', protein)
        except ValueError:
            protein = -999
            print("Please enter Protein manually!")
     
        if protein == -999:
            user_input = float(input("Please enter Protein: "))
            protein = user_input

    return protein

#CALCULATIONS
def calc(servings, calories, fats, cholesterol, sodium, carbohydrate, sugars, protein):
    outfile = open("NutriFacts.txt", 'a')
    
    true_cal = calories * servings
    outfile.write(str(true_cal))
    outfile.write(str('\n'))
    
    true_fat = fats * servings
    outfile.write(str(true_fat))
    outfile.write(str('\n'))
    
    true_chol = cholesterol * servings
    outfile.write(str(true_chol))
    outfile.write(str('\n'))
    
    true_sod = sodium * servings
    outfile.write(str(true_sod))
    outfile.write(str('\n'))
    
    true_carb = carbohydrate * servings
    outfile.write(str(true_carb))
    outfile.write(str('\n'))
    
    true_sug = sugars * servings
    outfile.write(str(true_sug))
    outfile.write(str('\n'))
    
    true_prot = protein * servings
    outfile.write(str(true_prot))
    outfile.write(str('\n'))

    outfile.close()

    return true_cal, true_fat, true_chol, true_sod, true_carb, true_sug, true_prot

#print

def print_s(true_cal, true_fat, true_chol, true_sod, true_carb, true_sug, true_prot):
    print("CALORIES FROM THIS ITEM: ", true_cal)
    print("TOTAL FAT FROM THIS ITEM: ", true_fat)
    print("CHOLESTEROL FROM THIS ITEM: ", true_chol)
    print("SODIUM FROM THIS ITEM: ", true_sod)
    print("CARBOHYDRATES FROM THIS ITEM: ", true_carb)
    print("SUGARS FROM THIS ITEM: ", true_sug)
    print("PROTEIN FROM THIS ITEM: ", true_prot)
    

def main():
    food = input("What did you eat?: ")
    outfile = open("NutriFacts.txt", 'w')
    outfile.write(str(food + '\n'))
    try:
        servings = float(input("Approximately how much did you have? (Please enter your amount as the number of servings you had (i.e. 1.5 servings): "))
        outfile = open("NutriFacts.txt", 'a')
        outfile.write(str(servings))
        outfile.write(str('\n'))
        outfile.close()
    except ValueError:
        print("Please enter a number or your number as a decimal!")
        servings = float(input("Approximately how much did you have? (Please enter your amount as the number of servings you had (i.e. 1.5 servings): "))
        outfile = open("NutriFacts.txt", 'a')
        outfile.write(str(servings))
        outfile.write(str('\n'))
        outfile.close()

    calories = cal()
    fats = fat()
    cholesterol = chol()
    sodium = sod()
    carbohydrate = carb()
    sugars = sug()
    protein = prot()

    true_cal, true_fat, true_chol, true_sod, true_carb, true_sug, true_prot = calc(servings,calories, fats, cholesterol, sodium, carbohydrate, sugars, protein)

    print_s(true_cal, true_fat, true_chol, true_sod, true_carb, true_sug, true_prot)
    
main()
