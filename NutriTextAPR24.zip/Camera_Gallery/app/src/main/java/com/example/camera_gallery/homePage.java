package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ActivityOptions;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.transition.Slide;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class homePage extends AppCompatActivity {
    TextView welcomeText, totalCal, dateView;
    ImageView imageView;
    Random rand = new Random();

    Date date = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
    String timeStamp = dateFormat.format(date);

    BottomNavigationView navigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);


        totalCal = findViewById(R.id.totalCal);


        dateView = findViewById(R.id.dateView);
        dateView.setText(timeStamp);
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/comicneue.ttf");
        dateView.setTypeface(custom_font);


        try {
            calcTotalCal();

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            calcAvgCal();
        } catch (IOException e) {
            e.printStackTrace();
        }


        welcomeText = findViewById(R.id.welcome);
        welcomeText.setText("Summary\n");

        int[] images = {R.drawable.img1,R.drawable.img2,R.drawable.img3, R.drawable.img4, R.drawable.img5, R.drawable.img6,
        R.drawable.img7};


        imageView = findViewById(R.id.imageView2);
        imageView.setImageResource(images[rand.nextInt(images.length)]);



        navigationView = findViewById(R.id.bottomNavigationView);
        navigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.navigation_new:{
                    makeNewRecord();
                    return true;
                }
                case R.id.navigation_archive:{
                    goToArchive();
                    return true;
                }
                case R.id.navigation_stats:{
                    Intent intent = new Intent(homePage.this, graph.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });
    }

    private void calcAvgCal() throws IOException {
        File f = new File(String.valueOf(homePage.this.getFilesDir()));
        System.out.println("HERE" + f);
        /*BufferedReader reader;
        reader = new BufferedReader(new FileReader(homePage.this.getFilesDir() + "/caloriesTotal/" + timeStamp + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentCal = Float.valueOf(line);
            totalCalories += currentCal;
            line = reader.readLine();


        }

         */

    }

    @SuppressLint("SetTextI18n")
    private void calcTotalCal() throws IOException {
        float currentCal;
        float totalCalories = 0;
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(homePage.this.getFilesDir() + "/caloriesTotal/" + timeStamp + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentCal = Float.valueOf(line);
            totalCalories += currentCal;
            line = reader.readLine();
        }


        totalCal.setText(Float.toString(totalCalories));
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/comicneue.ttf");
        totalCal.setTypeface(custom_font);
    }

    private void goToArchive() {
        Intent intent = new Intent(this, archivePage.class);
        startActivity(intent);
    }

    private void makeNewRecord() {
        Intent intent = new Intent(this, get_product_name.class);
        startActivity(intent);
    }
}
