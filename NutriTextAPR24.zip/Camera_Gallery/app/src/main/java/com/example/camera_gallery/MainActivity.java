package com.example.camera_gallery;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.MenuItem;
import android.view.Surface;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.common.FirebaseVisionImageMetadata;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static android.Manifest.permission.CAMERA;
import static android.app.ActionBar.*;
import static com.google.firebase.ml.vision.text.FirebaseVisionText.*;

public class MainActivity extends AppCompatActivity {

    public static final int CAMERA_REQUEST_CODE = 2;
    public static final int CAMERA_PERM_CODE = 1;
    public static final int GALLERY_REQUEST_CODE = 11;
    Button cameraBtn, galleryBtn;
    String currentPhotoPath;
    TextView choiceView;

    StorageReference storageReference;
    Date date = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
    String timeStamp = dateFormat.format(date);

    int flag = 0;

    BottomNavigationView bottomNavigationView;


    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();
    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewMain);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.navigation_homeViewArc:{
                    Intent intent = new Intent(MainActivity.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_new:{
                    Intent intent = new Intent(MainActivity.this, get_product_name.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_archive:{
                    Intent intent = new Intent(MainActivity.this, archivePage.class);
                    startActivity(intent);
                    return true;
                }

            }
            return false;
        });

        cameraBtn = findViewById(R.id.camera);
        galleryBtn = findViewById(R.id.gallery);
        choiceView = findViewById(R.id.choice);

        storageReference = FirebaseStorage.getInstance().getReference();
        cameraBtn.setOnClickListener(view -> askCamPermission());
        galleryBtn.setOnClickListener(view -> {

            Intent gallery = new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(gallery, GALLERY_REQUEST_CODE);
        });
    }

    private void askCamPermission() {
        if (ContextCompat.checkSelfPermission(this, CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{CAMERA}, CAMERA_PERM_CODE);
        } else {
            dispatchTakePictureIntent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_PERM_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            } else {
                Toast.makeText(this, "Camera Permission Required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (resultCode==Activity.RESULT_OK){



                File f = new File (currentPhotoPath);
                //selectedImage.setImageURI(Uri.fromFile(f));
                Log.d("Tag", "Absolute Url of image is " + Uri.fromFile(f));

                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                Uri contentUri = Uri.fromFile(f);

                mediaScanIntent.setData(contentUri);
                this.sendBroadcast(mediaScanIntent);

                Context ctx = this;


                //upload to Firebase
                //uploadToFirebase(f.getName(), contentUri);

                //start ML local analyzer
                try {
                    runTextRecognition(ctx, contentUri);
                    System.out.println("CAM " + flag);
                } catch (IOException e) {
                    e.printStackTrace();
                    showToast("FAILED");
                }
                if (contentUri == null){
                    Intent restart = getIntent();
                    finish();
                    startActivity(restart);
                }
                else
                    passBundle(0);
            }

        }

        if (requestCode == GALLERY_REQUEST_CODE) {
            if (resultCode==Activity.RESULT_OK){
                Uri contentUri = data.getData();
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String imageFileName = "JPEG_" + timeStamp + "." + getFileExt(contentUri);
                Log.d("Tag", "Gallery Image Uri: " + imageFileName);
                //selectedImage.setImageURI(contentUri);

                //upload to Firebase
                //uploadToFirebase(imageFileName, contentUri);

                Context ctx = this;
                //start ML local analyzer
                try {
                    runTextRecognition(ctx, contentUri);
                } catch (IOException e) {
                    e.printStackTrace();
                    showToast("FAILED");
                }

                if (contentUri == null){
                    Intent restart = getIntent();
                    finish();
                    startActivity(restart);
                }
                else
                    passBundle(0);
            }
        }

    }

    private void flag(){
        flag = 1;
    }

    private void runTextRecognition(Context d, Uri x) throws IOException {
        FirebaseVisionImage image = FirebaseVisionImage.fromFilePath(d, x);
        FirebaseVisionTextRecognizer detector = FirebaseVision.getInstance().getOnDeviceTextRecognizer();
        detector.processImage(image).addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
            @Override
            public void onSuccess(FirebaseVisionText firebaseVisionText) {
                    processTextRecognitionResult(firebaseVisionText);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void processTextRecognitionResult(FirebaseVisionText texts) {
        showToast("Processing");
        String result = texts.getText();
        List<FirebaseVisionText.TextBlock> blocks = texts.getTextBlocks();
        if (blocks.size() == 0){
            flag();
            showToast("No text found");
        }
        else{
            //showToast("Text Detected");
            for (FirebaseVisionText.TextBlock block : texts.getTextBlocks()){
                String blockText = block.getText();
                //SaveToFile(blockText);
                for (FirebaseVisionText.Line line : block.getLines()){
                    String lineText = line.getText();
                    //SaveToFile(lineText);
                    for (FirebaseVisionText.Element element : line.getElements()){
                        String elementText = element.getText();
                        SaveToFile(elementText);
                    }
                }
            }

            //showToast("Text Saved to txt file");
            Uri txtFile = Uri.fromFile(new File("/data/data/com.example.camera_gallery/files/NutriText/" + timeStamp + ".txt"));
            //TextFileUploadToFirebase("NutriText", txtFile);
            //createDateButton();


            //DeleteFile();


        /*for (int i = 0; i < blocks.size(); i++){
            List<FirebaseVisionText.Line> lines = blocks.get(i).getLines();

            for (int j = 0; j < lines.size(); j++){
                List<FirebaseVisionText.Element> elements = lines.get(j).getElements();

         */
        }
    }

    private void passBundle(int flag){
        Intent intent = getIntent();
        String name = intent.getStringExtra("key");
        Intent intent1 = new Intent(MainActivity.this, splashScreen2.class);
        intent1.putExtra("f", Integer.toString(flag));
        intent1.putExtra("key", name);
        startActivity(intent1);
    }


    private void SaveToFile(String myLine){
        File textFile = new File(MainActivity.this.getFilesDir(), "NutriText");
        if (!textFile.exists()){
            textFile.mkdir();
        }
        try{

            File testFile = new File(textFile, timeStamp + ".txt");
            FileWriter fw = new FileWriter(testFile, true);
            PrintWriter printWriter = new PrintWriter(fw);
            printWriter.println(myLine);
            fw.flush();
            fw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void TextFileUploadToFirebase(String name, Uri txtUri){
        final StorageReference txtUpload = storageReference.child("text/" + name);
        txtUpload.putFile(txtUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                txtUpload.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        showToast("Txt file upload Complete");
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                showToast("Txt file Upload Failed");
            }
        });
    }

    private void uploadToFirebase(String name, Uri contentUri) {
        final StorageReference imageUpload = storageReference.child("images/" + name);
        imageUpload.putFile(contentUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                imageUpload.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Toast.makeText(MainActivity.this, "Image Uploaded", Toast.LENGTH_SHORT).show();
                        Log.d("Tag", "On Success: Uploaded Image URI is : " + uri.toString());
                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, "Upload Failed", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


    private String getFileExt(Uri contentUri) {
        ContentResolver c = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(c.getType(contentUri));
    }


    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        //File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {

            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE);
            }
        }
    }

    /**
     * Get the angle by which an image must be rotated given the device's current
     * orientation.
     */
    /*
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private int getRotationCompensation(String cameraId, Activity activity, Context context)
            throws CameraAccessException {
        // Get the device's current rotation relative to its "native" orientation.
        // Then, from the ORIENTATIONS table, look up the angle the image must be
        // rotated to compensate for the device's rotation.
        int deviceRotation = activity.getWindowManager().getDefaultDisplay().getRotation();
        int rotationCompensation = ORIENTATIONS.get(deviceRotation);

        // On most devices, the sensor orientation is 90 degrees, but for some
        // devices it is 270 degrees. For devices with a sensor orientation of
        // 270, rotate the image an additional 180 ((270 + 270) % 360) degrees.
        CameraManager cameraManager = (CameraManager)activity.getSystemService(CAMERA_SERVICE);
        int sensorOrientation = cameraManager
                .getCameraCharacteristics(cameraId)
                .get(CameraCharacteristics.SENSOR_ORIENTATION);
        rotationCompensation = (rotationCompensation + sensorOrientation + 270) % 360;

        // Return the corresponding FirebaseVisionImageMetadata rotation value.
        int result;
        switch (rotationCompensation) {
            case 0:
                result = FirebaseVisionImageMetadata.ROTATION_0;
                break;
            case 90:
                result = FirebaseVisionImageMetadata.ROTATION_90;
                break;
            case 180:
                result = FirebaseVisionImageMetadata.ROTATION_180;
                break;
            case 270:
                result = FirebaseVisionImageMetadata.ROTATION_270;
                break;
            default:
                result = FirebaseVisionImageMetadata.ROTATION_0;
                Log.e("Tag", "Bad rotation value: " + rotationCompensation);
        }
        return result;
    }

     */
}
