package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class quantity_page extends AppCompatActivity {

    TextView amountText, servingText;
    TextInputEditText quantAsk;
    Button toMain;
    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quantity_page);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        toMain = findViewById(R.id.goToMain);
        quantAsk = findViewById(R.id.quantAsk);
        amountText = findViewById(R.id.AmountText);
        servingText = findViewById(R.id.servingText);
        bottomNavigationView = findViewById(R.id.bottomNavigationQuantityPage);

        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_homeViewArc: {
                    Intent intent = new Intent(quantity_page.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_new: {
                    Intent intent = new Intent(quantity_page.this, get_product_name.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_archive: {
                    Intent intent = new Intent(quantity_page.this, archivePage.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });

        servingText.setText("If you are unsure, enter 1");

        Intent intent = getIntent();
        final String value = intent.getStringExtra("key");
        amountText.setText("How many servings of " + value + "?");

        quantAsk.setOnEditorActionListener((v, actionId, event) -> {
            boolean handled = false;
            if (actionId == EditorInfo.IME_ACTION_GO){
                String quant = quantAsk.getText().toString();
                sendBundle(quant);
                handled = true;
            }
            return handled;
        });

        toMain.setOnClickListener(v -> {
            String quant = quantAsk.getText().toString();
            sendBundle(quant);
        });
    }

    private void sendBundle(String quantity){
        Intent intent1 = getIntent();
        final String value = intent1.getStringExtra("key");
        final String finalCal = intent1.getStringExtra("cal");
        final String finalFat = intent1.getStringExtra("fat");
        final String finalChol = intent1.getStringExtra("chol");
        final String finalSod = intent1.getStringExtra("sod");
        final String finalCarb = intent1.getStringExtra("carb");
        final String finalSug = intent1.getStringExtra("sug");
        final String finalPro = intent1.getStringExtra("pro");

        Intent intent2 = new Intent(quantity_page.this, viewCurrent.class);

        intent2.putExtra("key", value);
        intent2.putExtra("cal", finalCal);
        intent2.putExtra("fat", finalFat);
        intent2.putExtra("chol", finalChol);
        intent2.putExtra("sod", finalSod);
        intent2.putExtra("carb", finalCarb);
        intent2.putExtra("sug", finalSug);
        intent2.putExtra("pro", finalPro);
        intent2.putExtra("amt", quantity);

        startActivity(intent2);
    }
}
