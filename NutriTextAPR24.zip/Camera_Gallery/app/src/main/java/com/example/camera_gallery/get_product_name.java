package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class get_product_name extends AppCompatActivity {

    TextInputEditText productName;
    String product;
    Button saveName;
    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_product_name);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewProd);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.navigation_homeViewArc:{
                    Intent intent = new Intent(get_product_name.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_archive:{
                    Intent intent = new Intent(get_product_name.this, archivePage.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });

        productName = findViewById(R.id.productInput);
        saveName = findViewById(R.id.saveProductName);

        productName.setOnEditorActionListener((v, actionId, event) -> {
            boolean handled = false;
            if (actionId == EditorInfo.IME_ACTION_GO){
                savingName();
                handled = true;
            }
            return handled;
        });

        productName.setOnClickListener(view -> {
            product = productName.getText().toString();
        });

        saveName.setOnClickListener(view -> savingName());
    }

    private void savingName() {
        product = productName.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("key", product);
        startActivity(intent);
    }
}
