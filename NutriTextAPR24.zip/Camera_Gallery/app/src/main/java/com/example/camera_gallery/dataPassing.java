package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class dataPassing extends AppCompatActivity {

    Date date = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
    String timeStamp = dateFormat.format(date);

    int calIndex, fatIndex, cholIndex, sodIndex, carbIndex, sugIndex, proIndex;
    float calTemp, fatTemp, cholTemp, sodTemp, carbTemp, sugTemp, proTemp;

    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_passing);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewData);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.navigation_homeData:{
                        Intent intent = new Intent(dataPassing.this, homePage.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_newData:{
                        Intent intent = new Intent(dataPassing.this, get_product_name.class);
                        startActivity(intent);
                        return true;
                    }
                    case R.id.navigation_archiveData:{
                        Intent intent = new Intent(dataPassing.this, archivePage.class);
                        startActivity(intent);
                        return true;
                    }
                }
                return false;
            }
        });

        try {
            nutritionData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void DeleteFile(){
        File fileToDelete = new File(dataPassing.this.getFilesDir() + "/NutriText/" + timeStamp + ".txt");
        fileToDelete.delete();
    }

    private void nutritionData() throws IOException {

        FileReader in = new FileReader(dataPassing.this.getFilesDir() + "/NutriText/" + timeStamp + ".txt");
        String ok = dataPassing.this.getFilesDir() + "/NutriText/" + timeStamp + ".txt";
        Scanner s = new Scanner(new File(ok));
        BufferedReader reader = new BufferedReader(in);

        String line = reader.readLine();
        int lineNum = 1;
        while (line != null) {
            lineNum++;
            line = reader.readLine();
        }

        String[] arr = new String[lineNum];

        int j = 0;
        while (s.hasNext()) {
            arr[j] = s.next();
            j++;
        }

        String cal_lookup = "Calories";
        String fat_lookup = "Fat";
        String chol_lookup = "Cholesterol";
        String sod_lookup = "Sodium";
        String carb_lookup = "Carbohydrate";
        String sug_lookup = "Sugars";
        String pro_lookup = "Protein";

        int calFlag = 0, fatFlag = 0, cholFlag = 0, sodFlag = 0, carbFlag = 0, sugFlag = 0, proFlag = 0;


        for (int i = 0; i < lineNum; i++) {
            try {
                if (calFlag == 0 && ((cal_lookup.equals(arr[i])) || (arr[i].contains("Calo")) || (arr[i].contains("calo")) || (arr[i].equalsIgnoreCase("CALORIES")))) {
                    calIndex = ++i;
                    String removedUnit = arr[calIndex];
                    if (!(removedUnit.matches("-?\\d+(\\.\\d+)?"))) {
                        if (arr[calIndex-2].matches("-?\\d+(\\.\\d+)?")) {
                            removedUnit = arr[calIndex-2];
                            calTemp = Float.valueOf(removedUnit);
                            calFlag = 1;
                        }
                        else{
                            for (int k = calIndex; k < lineNum; k++) {
                                if (arr[k].matches("-?\\d+(\\.\\d+)?")) {
                                    removedUnit = arr[k];
                                    calTemp = Float.valueOf(removedUnit);
                                    calFlag = 1;
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        calTemp = Float.valueOf(removedUnit);
                        calFlag = 1;
                    }

                }
                if (fatFlag == 0 &&((fat_lookup.equals(arr[i])) || (arr[i].contains("fat")) || (arr[i].contains("Fat")) || (arr[i].equalsIgnoreCase("Fat")))) {
                    fatIndex = ++i;
                    String removedUnit = arr[fatIndex].replace("g", "");
                    if (removedUnit.equals("O") || !(removedUnit.matches("-?\\d+(\\.\\d+)?"))){
                        fatFlag = 1;
                        fatTemp = 0;
                    }
                    else{
                        fatFlag = 1;
                        fatTemp = Float.valueOf(removedUnit);
                    }
                }

                if (cholFlag == 0 && ((chol_lookup.equals(arr[i])) || (arr[i].contains("Chol")) || (arr[i].contains("chol")) || (arr[i].equalsIgnoreCase("Cholesterol")))) {
                    cholIndex = ++i;
                    String removedUnit = arr[cholIndex].replace("mg", "");
                    if (removedUnit.equals("O") || !(removedUnit.matches("-?\\d+(\\.\\d+)?"))){
                        cholFlag = 1;
                        cholTemp = 0;
                    }
                    else {
                        cholFlag = 1;
                        cholTemp = Float.valueOf(removedUnit);
                    }
                }

                if (sodFlag == 0 && ((sod_lookup.equals(arr[i])) || (arr[i].contains("Sodi")) || (arr[i].contains("sodi")) || (arr[i].equalsIgnoreCase("Sodium")))) {
                    sodIndex = ++i;
                    String removedUnit = arr[sodIndex].replace("mg", "");
                    if (removedUnit.equals("O") || !(removedUnit.matches("-?\\d+(\\.\\d+)?"))) {
                        sodFlag = 1;
                        sodTemp = 0;
                    }
                    else{
                        sodFlag = 1;
                        sodTemp = Float.valueOf(removedUnit);
                    }
                }

                if (carbFlag == 0 && ((carb_lookup.equals(arr[i])) || (arr[i].contains("Carbo")) || (arr[i].contains("carbo")) || (arr[i].equalsIgnoreCase("Carbohydrates")))) {
                    carbIndex = ++i;
                    String removedUnit = arr[carbIndex].replace("g", "");
                    if (removedUnit.equals("O") || !(removedUnit.matches("-?\\d+(\\.\\d+)?"))){
                        carbFlag = 1;
                        carbTemp = 0;
                    }

                    else{
                        carbFlag = 1;
                        carbTemp = Float.valueOf(removedUnit);
                    }
                }

                if (sugFlag == 0 && ((sug_lookup.equals(arr[i])) || (arr[i].equals("sugars")))) {
                    sugIndex = ++i;
                    String removedUnit = arr[sugIndex].replace("g", "");
                    if (removedUnit.equals("O") || !(removedUnit.matches("-?\\d+(\\.\\d+)?"))){
                        sugFlag = 1;
                        sugTemp = 0;
                    }
                    else{
                        sugFlag = 1;
                        sugTemp = Float.valueOf(removedUnit);
                    }
                }

                if (proFlag == 0 && ((pro_lookup.equals(arr[i])) || (arr[i].contains("Prot")) || (arr[i].contains("prot")) || (arr[i].equalsIgnoreCase("Protein")))) {
                    proIndex = ++i;
                    String removedUnit = arr[proIndex].replace("g", "");
                    if (removedUnit.equals("O") || !(removedUnit.matches("-?\\d+(\\.\\d+)?"))){
                        proFlag = 1;
                        proTemp = 0;
                    }
                    else{
                        proFlag = 1;
                        proTemp = Float.valueOf(removedUnit);
                    }
                }

            }catch (NullPointerException e){
                showToast("Did not spot any nutritional data");
            }
        }
        try{

            String cal1, fat1, chol1, sod1, carb1, sug1, pro1;
            cal1 = Float.toString(calTemp);
            fat1 = Float.toString(fatTemp);
            chol1 = Float.toString(cholTemp);
            sod1 = Float.toString(sodTemp);
            carb1 = Float.toString(carbTemp);
            sug1 = Float.toString(sugTemp);
            pro1 = Float.toString(proTemp);

            Intent nameIntent = getIntent();
            final String nameOfProd = nameIntent.getStringExtra("key");
            Intent intent2 = new Intent(this, verifyCurrent.class);
            intent2.putExtra("key", nameOfProd);
            intent2.putExtra("cal", cal1);
            intent2.putExtra("fat", fat1);
            intent2.putExtra("chol", chol1);
            intent2.putExtra("sod", sod1);
            intent2.putExtra("carb", carb1);
            intent2.putExtra("sug", sug1);
            intent2.putExtra("pro", pro1);
            startActivity(intent2);

        }catch (Exception e){
            showToast("Error Reading Image");
        }
        DeleteFile();
    }
}

