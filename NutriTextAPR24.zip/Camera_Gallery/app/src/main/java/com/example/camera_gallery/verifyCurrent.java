package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class verifyCurrent extends AppCompatActivity {

    TextView verName, verCal, verFat, verChol, verSod, verCarb, verSug, verPro;
    Button goToCurrent;
    String finalCal, finalFat, finalChol, finalSod, finalCarb, finalSug, finalPro;
    BottomNavigationView bottomNavigationView;


    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_current);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewVerify);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.navigation_archive:{
                    Intent intent = new Intent(verifyCurrent.this, archivePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_new:{
                    Intent intent = new Intent(verifyCurrent.this, get_product_name.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_homeViewArc:{
                    Intent intent = new Intent(verifyCurrent.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });

        goToCurrent = findViewById(R.id.goToCurrent);

        Intent intent = getIntent();
        final String value = intent.getStringExtra("key");
        final String cal = intent.getStringExtra("cal");
        final String fat = intent.getStringExtra("fat");
        final String chol = intent.getStringExtra("chol");
        final String sod = intent.getStringExtra("sod");
        final String carb = intent.getStringExtra("carb");
        final String sug = intent.getStringExtra("sug");
        final String pro = intent.getStringExtra("pro");


        verName = findViewById(R.id.prodNameVer);
        verName.setText(value);

        verCal = findViewById(R.id.calEdit);
        verCal.setText(cal);

        verFat = findViewById(R.id.fatEdit);
        verFat.setText(fat);

        verChol = findViewById(R.id.cholEdit);
        verChol.setText(chol);

        verSod = findViewById(R.id.sodEdit);
        verSod.setText(sod);

        verCarb = findViewById(R.id.carbEdit);
        verCarb.setText(carb);

        verSug = findViewById(R.id.sugEdit);
        verSug.setText(sug);

        verPro = findViewById(R.id.proEdit);
        verPro.setText(pro);

        goToCurrent.setOnClickListener(v -> {
            finalCal = verCal.getText().toString();
            finalFat = verFat.getText().toString();
            finalChol = verChol.getText().toString();
            finalSod = verSod.getText().toString();
            finalCarb = verCarb.getText().toString();
            finalSug = verSug.getText().toString();
            finalPro = verPro.getText().toString();

            if (finalCal == null){
                Intent intent3 = new Intent(verifyCurrent.this, quantity_page.class);
                startActivity(intent3);
            }

            else{
                Intent intent2 = new Intent(verifyCurrent.this, quantity_page.class);
                intent2.putExtra("key", value);
                intent2.putExtra("cal", finalCal);
                intent2.putExtra("fat", finalFat);
                intent2.putExtra("chol", finalChol);
                intent2.putExtra("sod", finalSod);
                intent2.putExtra("carb", finalCarb);
                intent2.putExtra("sug", finalSug);
                intent2.putExtra("pro", finalPro);
                startActivity(intent2);
            }
        });
    }
}
