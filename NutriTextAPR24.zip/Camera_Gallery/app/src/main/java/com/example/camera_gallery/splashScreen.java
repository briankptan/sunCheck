package com.example.camera_gallery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class splashScreen extends AppCompatActivity {

    Timer timer = new Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(splashScreen.this, homePage.class);
                startActivity(intent);
                finish();
            }
        },1500);
    }
}
