package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class viewCurrent extends AppCompatActivity {
    TextView date1, details;
    StringBuilder text = new StringBuilder();

    Date date = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
    String timeStamp = dateFormat.format(date);

    DateFormat formatTime = new SimpleDateFormat("hh:mm a");
    String timeNow = formatTime.format(new Date());

    float calories = 0, fat = 0, chol = 0, sod = 0, carb = 0, sug = 0, pro = 0;

    int counterD = 10;

    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_current);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        date1 = findViewById(R.id.dateView);
        details = findViewById(R.id.details);

        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
        String timeStamp = dateFormat.format(date);
        date1.setText(timeStamp);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewCurrent);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch(item.getItemId()){
                case R.id.navigation_homeViewArc:{
                    Intent intent = new Intent(viewCurrent.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_newViewArc:{
                    sendNumData();
                    return true;
                }
                case R.id.navigation_archiveViewArc:{
                    String numData = Integer.toString(counterD);
                    Intent intent = new Intent(viewCurrent.this, archivePage.class);
                    intent.putExtra("numData", numData);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });

        //displayDetails();

        try {
            writeReadData();
            collectCalData();
            collectFatData();
            collectCholData();
            collectSodData();
            collectCarbData();
            collectSugData();
            collectProData();
        } catch (IOException e) {
            e.printStackTrace();
        }
        DeleteFile();
    }

    private void goToHome() {
        Intent intent = new Intent(this, homePage.class);
        startActivity(intent);
    }

    private void displayDetails(){
        BufferedReader reader;
        File textFile = new File(viewCurrent.this.getFilesDir(), timeStamp);
        if (!textFile.exists()) {
            textFile.mkdir();

            try {
                File testFile = new File(textFile, "1" + ".txt");
                FileWriter fw = new FileWriter(testFile, true);
                PrintWriter printWriter = new PrintWriter(fw);

                reader = new BufferedReader(new FileReader(viewCurrent.this.getFilesDir() + "/NutriText/" + timeStamp + ".txt"));
                String line = reader.readLine();
                Intent intent = getIntent();
                final String value = intent.getStringExtra("key");
                printWriter.println(value);
                text.append(value);
                text.append("\n");
                while (line != null) {
                    text.append(line);
                    text.append("\n");
                    printWriter.println(line);
                    line = reader.readLine();
                }
                fw.flush();
                fw.close();
                details.setText(text);
            } catch (IOException e) {
            }
        }
        else{
            File directory = new File(viewCurrent.this.getFilesDir() + "/" + timeStamp);
            int count = directory.list().length;
                try {
                    String counter = Integer.toString(++count);
                    File testFile = new File(textFile, counter + ".txt");
                    FileWriter fw = new FileWriter(testFile, true);
                    PrintWriter printWriter = new PrintWriter(fw);

                    reader = new BufferedReader(new FileReader(viewCurrent.this.getFilesDir() + "/NutriText/" + timeStamp + ".txt"));

                    String line = reader.readLine();
                    Intent intent = getIntent();
                    final String value = intent.getStringExtra("key");
                    printWriter.println(value);
                    text.append(value);
                    text.append("\n");
                    while (line != null) {
                        text.append(line);
                        text.append("\n");
                        printWriter.println(line);
                        line = reader.readLine();
                    }
                    fw.flush();
                    fw.close();
                    details.setText(text);
                } catch (IOException e) {
                }
            }
        }

    private void DeleteFile(){
        File fileToDelete = new File(viewCurrent.this.getFilesDir() + "/NutriText/" + timeStamp + ".txt");
        fileToDelete.delete();
        //showToast("txt file deleted");
    }

    private void sendNumData() {
        String numData = Integer.toString(counterD);
        Intent intent = new Intent(this, archivePage.class);
        intent.putExtra("numData", numData);
        startActivity(intent);
    }

    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


    private void writeReadData() throws IOException {
        int counterT = 10;

        File directoryCount = new File(viewCurrent.this.getFilesDir(), "date");
        if (!directoryCount.exists())
            directoryCount.mkdir();

        File[] files = directoryCount.listFiles();
        int countD = files.length;

        File dataFile1 = new File(viewCurrent.this.getFilesDir(), "date" + "/" + timeStamp);

        if (!dataFile1.exists()) {
            counterD += countD;
            File dataFile = new File(viewCurrent.this.getFilesDir(), "date" + "/" + timeStamp);
            dataFile.mkdir();

            String nameCounter = Integer.toString(counterT);
            File nutritionText= new File(dataFile, nameCounter + ".txt");
            FileWriter fw = new FileWriter(nutritionText, true);
            PrintWriter printWriter = new PrintWriter(fw);

            Intent intent = getIntent();
            final String value = intent.getStringExtra("key");
            final String quantity = intent.getStringExtra("amt");

            try{
                float serve = Float.valueOf(quantity);

                final String cal1 = intent.getStringExtra("cal");
                final String fat1 = intent.getStringExtra("fat");
                final String chol1 = intent.getStringExtra("chol");
                final String sod1 = intent.getStringExtra("sod");
                final String carb1 = intent.getStringExtra("carb");
                final String sug1 = intent.getStringExtra("sug");
                final String pro1 = intent.getStringExtra("pro");

                float calF = Float.valueOf(cal1);
                float fatF = Float.valueOf(fat1);
                float cholF = Float.valueOf(chol1);
                float sodF = Float.valueOf(sod1);
                float carbF = Float.valueOf(carb1);
                float sugF = Float.valueOf(sug1);
                float proF = Float.valueOf(pro1);

                calories = calF * serve;
                fat = fatF * serve;
                chol = cholF * serve;
                sod = sodF * serve;
                carb = carbF * serve;
                sug = sugF * serve;
                pro = proF * serve;
            }catch(Exception e){
                showToast("I see nothing");
            }

            printWriter.println(value);
            printWriter.println(timeNow);

            printWriter.print("Serving Amount: ");
            printWriter.println(quantity);
            printWriter.println("\n");

            printWriter.print("Calories: ");
            printWriter.println(calories);
            printWriter.print("Fat: ");
            printWriter.println(fat + "g");
            printWriter.print("Cholesterol: ");
            printWriter.println(chol + "mg");
            printWriter.print("Sodium: ");
            printWriter.println(sod + "mg");
            printWriter.print("Carbohydrates: ");
            printWriter.println(carb + "g");
            printWriter.print("Sugars: ");
            printWriter.println(sug + "g");
            printWriter.print("Protein: ");
            printWriter.println(pro + "g");
            printWriter.println("_______________________");

            fw.flush();
            fw.close();

            BufferedReader reader;
            reader = new BufferedReader(new FileReader(nutritionText));
            String line = reader.readLine();

            while (line != null) {
                text.append(line);
                text.append("\n");
                line = reader.readLine();
            }

            details.setText(text);

        }
        else{
            File directory = new File(viewCurrent.this.getFilesDir(), "date" + "/" + timeStamp);
            int countT = directory.list().length;
            counterT += countT;

            String nameCounter = Integer.toString(counterT);
            File nutritionText= new File(dataFile1, nameCounter + ".txt");
            FileWriter fw = new FileWriter(nutritionText, true);
            PrintWriter printWriter = new PrintWriter(fw);

            Intent intent = getIntent();
            final String value = intent.getStringExtra("key");
            final String quantity = intent.getStringExtra("amt");

            try{
                float serve = Float.valueOf(quantity);

                final String cal1 = intent.getStringExtra("cal");
                final String fat1 = intent.getStringExtra("fat");
                final String chol1 = intent.getStringExtra("chol");
                final String sod1 = intent.getStringExtra("sod");
                final String carb1 = intent.getStringExtra("carb");
                final String sug1 = intent.getStringExtra("sug");
                final String pro1 = intent.getStringExtra("pro");

                float calF = Float.valueOf(cal1);
                float fatF = Float.valueOf(fat1);
                float cholF = Float.valueOf(chol1);
                float sodF = Float.valueOf(sod1);
                float carbF = Float.valueOf(carb1);
                float sugF = Float.valueOf(sug1);
                float proF = Float.valueOf(pro1);

                calories = calF * serve;
                fat = fatF * serve;
                chol = cholF * serve;
                sod = sodF * serve;
                carb = carbF * serve;
                sug = sugF * serve;
                pro = proF * serve;
            }catch(Exception e){
                showToast("I see nothing");
            }

            printWriter.println(value);
            printWriter.println(timeNow);

            printWriter.print("Serving Amount: ");
            printWriter.println(quantity);
            printWriter.println("\n");

            printWriter.print("Calories: ");
            printWriter.println(calories);
            printWriter.print("Fat: ");
            printWriter.println(fat + "g");
            printWriter.print("Cholesterol: ");
            printWriter.println(chol + "mg");
            printWriter.print("Sodium: ");
            printWriter.println(sod + "mg");
            printWriter.print("Carbohydrates: ");
            printWriter.println(carb + "g");
            printWriter.print("Sugars: ");
            printWriter.println(sug + "g");
            printWriter.print("Protein: ");
            printWriter.println(pro + "g");
            printWriter.println("_______________________");

            fw.flush();
            fw.close();

            BufferedReader reader;
            reader = new BufferedReader(new FileReader(nutritionText));
            String line = reader.readLine();

            while (line != null) {
                text.append(line);
                text.append("\n");
                line = reader.readLine();
            }

            details.setText(text);
            if (calories == 0){
                showToast("Apparently, all you did was breathe...or drank water");
            }
        }
    }

    private void collectCalData() throws IOException {
        File calData = new File(viewCurrent.this.getFilesDir(), "caloriesTotal");
        if (!calData.exists())
            calData.mkdir();

        File calFile = new File(calData + "/" + timeStamp);
        if (!calFile.exists())
            calFile.mkdir();

        File calToWrite = new File(calFile + "/total.txt");
        FileWriter fw = new FileWriter(calToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(calories);
        fw.flush();
        fw.close();
    }

    private void collectFatData() throws IOException {
        File fatData = new File(viewCurrent.this.getFilesDir(), "fatTotal");
        if (!fatData.exists())
            fatData.mkdir();

        File fatFile = new File(fatData + "/" + timeStamp);
        if (!fatFile.exists())
            fatFile.mkdir();

        File fatToWrite = new File(fatFile + "/total.txt");
        FileWriter fw = new FileWriter(fatToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(fat);
        fw.flush();
        fw.close();
    }

    private void collectCholData() throws IOException {
        File cholData = new File(viewCurrent.this.getFilesDir(), "cholTotal");
        if (!cholData.exists())
            cholData.mkdir();

        File cholFile = new File(cholData + "/" + timeStamp);
        if (!cholFile.exists())
            cholFile.mkdir();

        File cholToWrite = new File(cholFile + "/total.txt");
        FileWriter fw = new FileWriter(cholToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(chol);
        fw.flush();
        fw.close();
    }

    private void collectSodData() throws IOException {
        File sodData = new File(viewCurrent.this.getFilesDir(), "sodTotal");
        if (!sodData.exists())
            sodData.mkdir();

        File sodFile = new File(sodData + "/" + timeStamp);
        if (!sodFile.exists())
            sodFile.mkdir();

        File sodToWrite = new File(sodFile + "/total.txt");
        FileWriter fw = new FileWriter(sodToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(sod);
        fw.flush();
        fw.close();
    }

    private void collectCarbData() throws IOException {
        File carbData = new File(viewCurrent.this.getFilesDir(), "carbTotal");
        if (!carbData.exists())
            carbData.mkdir();

        File carbFile = new File(carbData + "/" + timeStamp);
        if (!carbFile.exists())
            carbFile.mkdir();

        File carbToWrite = new File(carbFile + "/total.txt");
        FileWriter fw = new FileWriter(carbToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(carb);
        fw.flush();
        fw.close();
    }

    private void collectSugData() throws IOException {
        File sugData = new File(viewCurrent.this.getFilesDir(), "sugTotal");
        if (!sugData.exists())
            sugData.mkdir();

        File sugFile = new File(sugData + "/" + timeStamp);
        if (!sugFile.exists())
            sugFile.mkdir();

        File sugToWrite = new File(sugFile + "/total.txt");
        FileWriter fw = new FileWriter(sugToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(sug);
        fw.flush();
        fw.close();
    }

    private void collectProData() throws IOException {
        File proData = new File(viewCurrent.this.getFilesDir(), "proTotal");
        if (!proData.exists())
            proData.mkdir();

        File proFile = new File(proData + "/" + timeStamp);
        if (!proFile.exists())
            proFile.mkdir();

        File proToWrite = new File(proFile + "/total.txt");
        FileWriter fw = new FileWriter(proToWrite, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(pro);
        fw.flush();
        fw.close();
    }

}
