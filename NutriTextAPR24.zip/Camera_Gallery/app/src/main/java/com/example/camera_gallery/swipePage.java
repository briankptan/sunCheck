package com.example.camera_gallery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.View;
import android.widget.TextView;

import java.util.Objects;

public class swipePage extends AppCompatActivity {

    TextView intro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swipe_page);

        if (getSupportActionBar() != null)
            getSupportActionBar().hide();

        intro = findViewById(R.id.intro);

        String welcome = "Welcome to NutriText\n" +
                "The nutrition label reader\n" +
                "Swipe left to begin";
        intro.setText(welcome);

    }
}
