package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class viewArchive extends AppCompatActivity {


    TextView archiveText, archiveTextDate;
    StringBuilder text = new StringBuilder();

    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_archive);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewArchive1);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.navigation_homeViewArc:{
                    Intent intent = new Intent(viewArchive.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_newViewArc:{
                    Intent intent = new Intent(viewArchive.this, get_product_name.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_archiveViewArc:{
                    Intent intent = new Intent(viewArchive.this, archivePage.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });

        archiveText = findViewById(R.id.archiveText);
        archiveTextDate = findViewById(R.id.archiveTextDate);

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");


        archiveText.setMovementMethod(new ScrollingMovementMethod());
        archiveTextDate.setText(value);

        try {
            processText();
        } catch (IOException e) {
            showToast("ERROR AT PROCESSING");
            e.printStackTrace();
        }

        try {
            totalCal();
            totalFat();
            totalChol();
            totalSod();
            totalCarb();
            totalSug();
            totalPro();
        } catch (IOException e) {
            e.printStackTrace();
        }

        showText();

        //DeleteFile();
    }

    private void processText() throws IOException {
        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        File textFile = new File(viewArchive.this.getFilesDir(), value + "final");
        if (!textFile.exists()) {
            textFile.mkdir();
        }

        File directory = new File(viewArchive.this.getFilesDir() + "/date/" + value);
        File[] files = directory.listFiles();
        int count = files.length;
        String num = Integer.toString(count);

        int fileCount = count + 9;
        for (int i = fileCount; i > 9; i--){
            File testFile = new File(textFile,  "final.txt");
            FileWriter fw = new FileWriter(testFile, true);
            PrintWriter printWriter = new PrintWriter(fw);
            BufferedReader reader;
            String counter = Integer.toString(i);
            reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/date/" + value + "/" + counter + ".txt"));
            String line = reader.readLine();
            while (line != null){
                printWriter.println(line);
                line = reader.readLine();
            }
            printWriter.println('\n');
            fw.flush();
            fw.close();
            reader.close();
        }


    }
    private void showText() {
        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/" + value + "final" + "/" + "final.txt"));
            String line = reader.readLine();
            while (line != null){
                text.append(line);
                text.append('\n');
                line = reader.readLine();
            }
            archiveText.setText(text);
        }catch (IOException e){

        }
    }

    private void DeleteFile(){
        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        File fileToDelete = new File(viewArchive.this.getFilesDir() + "/" + value + "final" + "/" + "final.txt");
        fileToDelete.delete();
    }

    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void totalCal() throws IOException {
        float totalCalories = 0;
        float currentCal;
        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/caloriesTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentCal = Float.valueOf(line);
            totalCalories += currentCal;
            line = reader.readLine();
        }
        final String calToPrint = Float.toString(totalCalories);
        text.append("Total Calories: ").append(calToPrint);
        text.append("\n");
    }

    private  void totalFat() throws IOException {
        float totalFat = 0;
        float currentFat;

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/fatTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentFat = Float.valueOf(line);
            totalFat += currentFat;
            line = reader.readLine();
        }
        final String fatToPrint = Float.toString(totalFat);
        text.append("Total Fat: ").append(fatToPrint).append("g");
        text.append("\n");
    }

    private  void totalChol() throws IOException {
        float totalChol = 0;
        float currentChol;

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/cholTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentChol = Float.valueOf(line);
            totalChol += currentChol;
            line = reader.readLine();
        }
        final String cholToPrint = Float.toString(totalChol);
        text.append("Total Cholesterol: ").append(cholToPrint).append("mg");
        text.append("\n");
    }

    private  void totalSod() throws IOException {
        float totalSod = 0;
        float currentSod;

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/sodTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentSod = Float.valueOf(line);
            totalSod += currentSod;
            line = reader.readLine();
        }
        final String sodToPrint = Float.toString(totalSod);
        text.append("Total Sodium: ").append(sodToPrint).append("mg");
        text.append("\n");
    }

    private  void totalCarb() throws IOException {
        float totalCarb = 0;
        float currentCarb;

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/carbTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentCarb = Float.valueOf(line);
            totalCarb += currentCarb;
            line = reader.readLine();
        }
        final String carbToPrint = Float.toString(totalCarb);
        text.append("Total Carbohydrates: ").append(carbToPrint).append("g");
        text.append("\n");
    }

    private  void totalSug() throws IOException {
        float totalSug = 0;
        float currentSug;

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/sugTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentSug = Float.valueOf(line);
            totalSug += currentSug;
            line = reader.readLine();
        }
        final String sugToPrint = Float.toString(totalSug);
        text.append("Total Sugars: ").append(sugToPrint).append("g");
        text.append("\n");
    }

    private  void totalPro() throws IOException {
        float totalPro = 0;
        float currentPro;

        Intent intent2 = getIntent();
        final String value = intent2.getStringExtra("dateKey");
        BufferedReader reader;
        reader = new BufferedReader(new FileReader(viewArchive.this.getFilesDir() + "/proTotal/" + value + "/total.txt"));
        String line = reader.readLine();
        while (line != null){
            currentPro = Float.valueOf(line);
            totalPro += currentPro;
            line = reader.readLine();
        }
        final String proToPrint = Float.toString(totalPro);
        text.append("Total Protein: ").append(proToPrint).append("g");
        text.append("\n");
        text.append("________________________").append("\n").append("\n");
    }
}
