package com.example.camera_gallery;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

import static android.app.ActionBar.*;

public class splashScreen2 extends AppCompatActivity {

    Timer timer = new Timer();

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen2);
        //        getSupportActionBar().setTitle("NutriText");
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                Intent intent = getIntent();
                String flag = intent.getStringExtra("f");
                System.out.println("HERESP");
                System.out.println("flag = " + flag);

                if (!(flag.equals("0"))){
                    Intent empty = new Intent(splashScreen2.this, viewCurrent.class);
                    startActivity(empty);
                    finish();
                }
                else{
                    final String value = intent.getStringExtra("key");
                    Intent intent2 = new Intent(splashScreen2.this, dataPassing.class);
                    intent2.putExtra("key", value);
                    startActivity(intent2);
                    finish();
                }
            }
        },3000);
    }
}




