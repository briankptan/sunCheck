package com.example.camera_gallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.fonts.FontFamily;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

import static android.app.ActionBar.DISPLAY_SHOW_CUSTOM;

public class archivePage extends AppCompatActivity {

    TextView archiveText;
    BottomNavigationView bottomNavigationView;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archive_page);
        getSupportActionBar().setDisplayOptions(DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        bottomNavigationView = findViewById(R.id.bottomNavigationViewArchive);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.navigation_homeViewArc:{
                    Intent intent = new Intent(archivePage.this, homePage.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_new:{
                    Intent intent = new Intent(archivePage.this, get_product_name.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        });

        archiveText = findViewById(R.id.archiveView);


        try {
            findFileName();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {

            File[] allDir = new File(archivePage.this.getFilesDir(), "date").listFiles(File::isDirectory);
            int numOfAllDir = allDir.length;

            Date[] dateArray = new Date[numOfAllDir];

            String[] dateSorted = new String[numOfAllDir];
            for (int i = 0; i < numOfAllDir; i ++){
                dateSorted[i] = allDir[i].getName();
                Date dateList = new Date(allDir[i].lastModified());
                dateArray[i] = dateList;
            }

            for (int i = 0; i < numOfAllDir-1; i++){
                for (int j = 0; j < numOfAllDir-i-1; j++){
                    if (dateArray[j].before(dateArray[j+1])){

                        String temp2 = dateSorted[j];
                        dateSorted[j] = dateSorted[j+1];
                        dateSorted[j+1] = temp2;

                        Date temp = dateArray[j];
                        dateArray[j] = dateArray[j+1];
                        dateArray[j+1] = temp;
                    }
                }
            }

            TextView[] tvArr = new TextView[numOfAllDir];
            TextView textView;
            Typeface custom_font = Typeface.createFromAsset(getAssets(), "fonts/comicneue.ttf");

            LinearLayout myLinearLayout = findViewById(R.id.myLinearLayout);

            for (int i = 0; i < numOfAllDir; i++) {

                textView = new TextView(this);
                textView.setId(View.generateViewId());

                textView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 100, 1));
                myLinearLayout.addView(textView);

                tvArr[i] = textView;
                String useThis1 = dateSorted[i];

                textView.setText(useThis1);
                textView.setTextColor(Color.parseColor("#6C5E3E"));
                textView.setTextSize(20);
                textView.setTypeface(custom_font);
                tvArr[i].setOnClickListener(v -> sendDateLabel(useThis1));
            }
        } catch (Exception e){
            showToast("Empty Archive");
        }
    }

    private void findFileName() throws IOException {
        try {
            File[] myFileList = new File (archivePage.this.getFilesDir(), "date").listFiles(File::isDirectory);
            String[] fileName = new String[myFileList.length];

            for (int i = 0; i < myFileList.length; i++){
                fileName[i] = myFileList[i].getName();
            }

        }catch (Exception e){
            showToast("Empty Archives");
        }
    }

    private void sendDateLabel(String dateForArchive){
        Intent intent = new Intent(archivePage.this, viewArchive.class);
        intent.putExtra("dateKey", dateForArchive);
        startActivity(intent);
    }

    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
